import pandas as pd
import requests
import json
import os
import sys
import csv
import re
import ast
key = "sk-a4152196f16845598b062a9a1fc82f38"

# Chat Completion API Call
def chat_with_model(token, promp, model):
    url = 'https://llm.grit.ucsb.edu/api/chat/completions'
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
        'response_format': 'json_object'
    }
    
    data = {
      "model": model,
      "messages": [
        {
          "role": "user",
          "content": promp
        }
      ]
    }
    response = requests.post(url, headers=headers, json=data)
    return response.json()

if __name__ ==  "__main__": 

    out_csv = sys.argv[1]
    root_json = sys.argv[2]

    model = "phi4:latest"

    # "ID", "PAGE_NUMBER", "LATITUDE", "LONGITUDE", "TOWNSHIPS_RANGES_SECTIONS", "WATERSOURCE_NAME", "LOCATION", "COUNTY", "DATE_OF_DATA", "RESOLUTION","UNITS_USED", "WATER_TYPE"
    # "ID", "PAGE_NUMBER", "LATITUDE", "LONGITUDE", "WATERSOURCE_NAME", "COUNTY", "DATE_OF_DATA", "RESOLUTION", "WATER_TYPE"
    # "ID", "PAGE_NUMBER", "LATITUDE", "LONGITUDE", "COUNTY", "DATE_OF_DATA", "WATER_TYPE"

    columns = [
        "ID", "PAGE_NUMBER", "Latitude", "Longitude", "Townships_Ranges_Sections",
        "Watersource_Name", "County","Dates_of_Recording", "Temporal_Resolution",
        "Units_Of_Measurement", "Water_Type"
    ]

    df = pd.DataFrame(columns=columns)

    for f in os.listdir(root_json):
        filep = os.path.join(root_json, f)
        id = f.split('_')[0]
        page_num = f.split('_')[-1][:-5]
        print(id, page_num)

        input = ""
        
        with open(filep) as json_file:
            parsed = json.load(json_file)['result']['chunks']

        if parsed == []:
            continue
        else:
            # input = parsed[0]['content']
            for content in parsed:
                input = input + content['content']

        # Terms we want to capture
        v1 = "Groundwater", "Stream Discharge", "Precipitation", "Springs", "Reservoir", "Irrigation", "Water Quality"

        v2 = "Groundwater well", "Groundwater recharge", "Stream discharge", "Precipitation", "Springs", "Groundwater water quality", "Spring water quality", "Stream water quality", "Irrigation", "Reservoir", "Other (Choose a water type that best describes the data)"

        v3 = "Groundwater", "Stream", "Precipitation", "Springs", "Reservoir", "Other (Choose a water type that best describes the data)" 
        
        r1_summarize = f"""
            Reply only with valid JSON format and remember to escape all double quotes inside the the values. 

            {{
            "Watersource_Name" : ...,
            "County": ...,
            "Townships_Ranges_Sections": ...(Do not include Latitude nor Longitude here),
            "Temporal_Resolution": ...(time interval between sequential measurements),
            "Units_Of_Measurement": ...,
            "Latitude": ... (number in decimals),
            "Longitude": ... (number in decimals),
            "Dates_of_Recording": ... ,
            "Water_Type": {v1}
            }}

            There may be multiple watersources. In the case that multiple water sources are present, list out each water source individually.

            [{{
            "Watersource_Name" : ...,
            "County": ...,
            "Townships_Ranges_Sections": ...(Do not include Latitude nor Longitude here),
            "Temporal_Resolution": ...(time interval between sequential measurements),
            "Units_Of_Measurement": ...,
            "Latitude": ... (number in decimals),
            "Longitude": ... (number in decimals),
            "Dates_of_Recording": ... ,
            "Water_Type": {v1}
            }}, 
            {{
            "Watersource_Name" : ...,
            "County": ...,
            "Townships_Ranges_Sections": ...(Do not include Latitude nor Longitude here),
            "Temporal_Resolution": ...(time interval between sequential measurements),
            "Units_Of_Measurement": ...,
            "Latitude": ... (number in decimals),
            "Longitude": ... (number in decimals),
            "Dates_of_Recording": ... ,
            "Water_Type": {v1}.
            }},
            ...
            ]

            Some documents may have tables with column names that are misleading or incorrect. Double check the given categories.
            Double-check your answers. Make sure that it is compatible with json.loads() and there are commas separating each key-value pair and each JSON Object. Do not give examples or comments inside the JSON chunk. 

            Here is the document content:\n{input}\n
        
            """

        doc_summary = chat_with_model(key, r1_summarize, model)['choices'][0]['message']['content']
        print(doc_summary)

        match = re.search(r"```json\s*(.*?)\s*```", doc_summary, re.DOTALL)
        if match:
            cleaned_json = match.group(1)
        else:
            continue
        print(cleaned_json)
        try:
            dicts = json.loads(cleaned_json) 
            if isinstance(dicts, list):
                for dic in dicts:
                    dic.update({"ID": id, "PAGE_NUMBER": page_num})
                df = pd.concat([df, pd.DataFrame(dicts)], ignore_index=True)
            else:
                dicts.update({"ID": id, "PAGE_NUMBER": page_num})
                df = pd.concat([df, pd.DataFrame([dicts])], ignore_index=True)
        except Exception as e:
            try:
                cleaned_json = ''.join(cleaned_json.rsplit(',', 1)[0]) + "]"
                dicts = json.loads(cleaned_json) 
                if isinstance(dicts, list):
                    for dic in dicts:
                        dic.update({"ID": id, "PAGE_NUMBER": page_num})
                    df = pd.concat([df, pd.DataFrame(dicts)], ignore_index=True)
                else:
                    dicts.update({"ID": id, "PAGE_NUMBER": page_num})
                    df = pd.concat([df, pd.DataFrame([dicts])], ignore_index=True)
            except Exception as ex:
                print(ex)
    df.to_csv(out_csv)



