import pandas as pd
import requests
import json
import os
import sys
import csv
import re
import ast
key = "sk-a4152196f16845598b062a9a1fc82f38"

# Chat Completion API Call
def chat_with_model(token, promp, model):
    url = 'https://llm.grit.ucsb.edu/api/chat/completions'
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
        'response_format': 'json_object'
    }
    
    data = {
      "model": model,
      "messages": [
        {
          "role": "user",
          "content": promp
        }
      ]
    }
    response = requests.post(url, headers=headers, json=data)
    return response.json()

if __name__ ==  "__main__": 

    out_csv = sys.argv[1]
    root_json = sys.argv[2]

    model = "llama3:latest"

    columns = [
        "ID", "PAGE_NUMBER", "LATITUDE", "LONGITUDE", "TOWNSHIPS_RANGES_SECTIONS",
        "WATERSOURCE_NAME", "LOCATION", "COUNTY", "DATE_OF_DATA", "TIME_RANGE",
        "UNITS_USED", "WATER_TYPE"
    ]

    df = pd.DataFrame(columns=columns)

    for f in os.listdir(root_json):
        filep = os.path.join(root_json, f)
        id = f.split('_')[0]
        page_num = f.split('_')[-1][:-5]
        print(id, page_num)

        with open(filep) as json_file:
            data = json.load(json_file)['result']['chunks']

        parsed = ""

        for bbox in data:
            for block in bbox['blocks']:
                if block['type'] == 'Header':
                    parsed = parsed + block['content']
                elif block['type'] == 'Table':
                    parsed = parsed + block['content']
        
        if parsed == "":
            continue

        prompt = f"""
            You are an assistant that only responds with JSON in the following format:
            
            \n\n
            {{
            
            \n

            {{
            \n \"LATITUDE\": \"...\", 
            \n \"LONGITUDE\": \"...\",
            \n \"TOWNSHIPS_RANGES_SECTIONS\": \"...\",
            \n \"WATERSOURCE_NAME\": \"...\",
            \n \"LOCATION\": \"...\", 
            \n \"COUNTY\": \"...\", 
            \n \"DATE_OF_DATA\": \"DD-MM-YYYY to DD-MM-YYYY\",
            \n \"TIME_RANGE\": \"...\",  
            \n \"UNITS_USED\": \"...\",  
            \n \"WATER_TYPE\": \"...\"
            \n }},

            \n

              {{
            \n \"LATITUDE\": \"...\", 
            \n \"LONGITUDE\": \"...\",
            \n \"TOWNSHIPS_RANGES_SECTIONS\": \"...\",
            \n \"WATERSOURCE_NAME\": \"...\",
            \n \"LOCATION\": \"...\", 
            \n \"COUNTY\": \"...\", 
            \n \"DATE_OF_DATA\": \"DD-MM-YYYY to DD-MM-YYYY\",
            \n \"TIME_RANGE\": \"...\",  
            \n \"UNITS_USED\": \"...\",  
            \n \"WATER_TYPE\": \"...\"
            \n }},

            \n

              {{
            \n \"LATITUDE\": \"...\", 
            \n \"LONGITUDE\": \"...\",
            \n \"TOWNSHIPS_RANGES_SECTIONS\": \"...\",
            \n \"WATERSOURCE_NAME\": \"...\",
            \n \"LOCATION\": \"...\", 
            \n \"COUNTY\": \"...\", 
            \n \"DATE_OF_DATA\": \"DD-MM-YYYY to DD-MM-YYYY\",
            \n \"TIME_RANGE\": \"...\",  
            \n \"UNITS_USED\": \"...\",  
            \n \"WATER_TYPE\": \"...\"
            \n }}
            
            \n
            }}
            \n\n
            Input the string literal "NA" with double quotes if information is not available. TIME_RANGE is the frequency of data (daily, monthly, yearly, etc).
            \n
            Select the WATER_TYPE that best fits one of these: ["Groundwater", "Discharge", "Precipitation", "Springs", "Irrigation", "Chemical analyses", "Reservoir", "Recharge"].
            \n
            Here is the input:\n{parsed}\n
            
            \n
            
            Respond ONLY with valid JSON. Respond only with the variables included in the format. Do not include markdown or explanations.
            """

        res = chat_with_model(key, prompt, model)
        print(res['choices'][0]['message']['content'])
        print(type(res['choices'][0]['message']['content']))

        json_obj = "{0}".format(res['choices'][0]['message']['content'])
        cleaned_json = json_obj.replace("...", "").replace(" NA,", " \"NA\",")
        print(cleaned_json)
        try:
            dicts = json.loads(cleaned_json) 
            print(dicts)
            if isinstance(dicts, list):
                for dic in dicts:
                    dic.update({"ID": id, "PAGE_NUMBER": page_num})
                df = pd.concat([df, pd.DataFrame(dicts)], ignore_index=True)
            else:
                dicts.update({"ID": id, "PAGE_NUMBER": page_num})
                df = pd.concat([df, pd.DataFrame([dicts])], ignore_index=True)
        except Exception as e:
            print(e)

    df.to_csv(out_csv)